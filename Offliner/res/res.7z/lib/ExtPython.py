#!/usr/bin/env python
# -*- coding: utf-8 -*-
#:ExtPython.py
"""
ExtPython
	to extend Python
"""
import threading,time,re
__all__=['setTimeout','setInterval','Object','intval','floatval','boolval','dateval','isalnum']

def main():
	def test(p="-"*10,q="-"*10):
		print p
		print "Test!!!"
		print time.time()
		print q

	#print time.time()
	#setInterval(test,1,10,("K",),{"q":"Q"})
	#setTimeout(test,3,("K",),{"q":"Q"})
	#setTimeout(test,3)
	#print "Start!!!"
	print intval('128asdfsda',16)

	return 0

patterns={
'10':re.compile(r'^\s*((?:\+|-)?\d+\.?\d*)'),
'16':re.compile(r'^\s*((?:0x)?[0-9a-f]+)',re.I),
'8':re.compile(r'^\s*(0?[0-7]+)'),
'2':re.compile(r'^\s*((?:0b)?[01]+)',re.I),
'digit':re.compile('\d+'),
'alnum':re.compile('\w+'),
}


class Object(object):
	def __ne__(self,another):
		return not self==another

def setTimeout(func,timeout,args=(),kargs={}):
	state={'stop':False}
	def wrap():
		if state['stop']:return False
		time.sleep(timeout)
		func(*args,**kargs)
	thread=threading.Thread(target=wrap)
	thread.start()
	def stop(b=True):
		state['stop']=b
	return thread,stop

def setInterval(func,timeout,times=0,args=(),kargs={}):
	state={'stop':False}
	def wrap():
		t=times
		while not state['stop']:
			ret=func(*args,**kargs)
			if ret:break
			t-=1
			if t==0:break
			time.sleep(timeout)

	thread=threading.Thread(target=wrap)
	thread.start()
	def stop(b=True):
		state['stop']=b
	return thread,stop

def intval(i,radix=10):
	m=patterns.get(str(radix),patterns['10']).findall(i)
	if not m:return
	m=m[0]
	if '.' in m:
		m=m[0:m.find('.')]
	return int(m,radix)

def floatval(f):
	m=patterns['10'].findall(f)
	if not m:return
	return float(m[0])

def boolval(s):
	s=s.strip().lower()
	return s=='true'

def dateval(dtstr):
	from datetime import datetime
	dtlist=patterns['digit'].findall(dtstr)
	dtlist=map(int,dtlist)
	return datetime(*dtlist)


def isalnum(s):
	s=patterns['alnum'].sub('',s)
	return not s


def slash(s):
	return s.replace("\\","\\\\").replace("'","\\'").replace('"','\\"').replace("\n","\\n").replace("\r","\\r")


if __name__=='__main__':
	main()
