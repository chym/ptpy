#!/usr/bin/env python
# -*- coding: utf-8 -*-
#:LinkParser.py
import re,os,urlparse
from FileUtils import *
from ExtPython import *




__all__=['filter_links','parse_css_link','parse_js_link','parse_html_link','parse_link']

def main():
	#css=open('tmp/test.css').read()
	#links=parse_css_link(css)
	#html=open('tmp/test.htm').read()
	#links=parse_html_link(html)
	#print links
	#links=filter_links(links,'g.cn','http://www.g.cn/','/base/')
	#print links
	return 0

patterns={
	"normal_url":re.compile(r'''(?:http|ftp|https)://[a-z\.0-9-](?:\:[0-9]+)?[^"'()\[\]\n\r{}<>]+''',re.I),
	"css_url":re.compile(r'''url\(\s*"?'?\s*([^"'\(\)\n\r]+)\s*'?"?\s*\)''',re.I),
	"css_import":re.compile(r'''@import\s+'?"?\s*([^"'"\n\r]*)'?"?\s*''',re.I),
	"inline_css":re.compile(r'''<style[^<>]*>\s*([^<>]+)\s*</style>''',re.I|re.DOTALL),
	"html_tag":re.compile('<([a-z0-9]+[^<>]+)>',re.I|re.DOTALL),
	"inline_script":re.compile('<script\s+[^>]*src="?\'?([^"\'\n\r><]+)"?\'?',re.I),
	"html_url":re.compile(r'''\b(?:href|src|archive|codebase|data|code|usemap|ismap|action|cite|background|longdesc)\s*=\s*"?'?\s*(?!#)([^'"<>*\n\r()]+)\s*"?'?''',re.I),
	"html_style_attr":re.compile(r'''\b(?:on[a-z]+|style)\s*=\s*"?'?\s*([^"'\n\r<>]+)\s*"?'?''',re.I),
}


def filter_links(links,domain,cur_path,under_path=None):
	"""
	filter_links(links,domain,cur_path,under_path=None)
	filter the links that not under the same domain
	convert the link to a absolute path
	filter the links that not under the "under_path" if provided
	cur_path must endswith '/',example "http://www.g.cn/"
	"""
	links=filter(lambda l:samedomain(domain,l),links)
	def convert(l):
		rl=realurl(l,w=True)
		if '://' not in rl:
			rl=realurl(urlparse.urljoin(cur_path,rl),w=True)
		return rl
	links=map(convert,links)
	if under_path:
		links=filter(lambda l:parseurl(l)['path'].startswith(under_path),links)
	return links

def parse_css_link(css,proc=None):
	"""
	parse_css_link(css,proc=None)
	parse the link in css,such as background:url("../images/bg.gif"),import "../style.css" ...
	"""
	links=set()
	def pool_url(m):
		url=m.group(1)
		s=m.group(0)
		if url:
			if proc:
				purl=proc(url)
				if not purl:return s
				links.add(purl)
				return s.replace(url,purl)
			else:
				links.add(url)
	css=patterns["css_url"].sub(pool_url,css)
	css=patterns["css_import"].sub(pool_url,css)
	return links,css

def parse_js_link(js,proc=None):
	"""
	parse_js_link(js,proc=None)
	parse the link in js
	"""
	return parse_html_link(js,proc)[0],js

def parse_html_link(html,proc=None,proc_script=None):
	"""
	parse_html_link(html,proc=None)
	parse the link in html-tags,args the same as parse_css_link
	"""
	links=set()
	def sub_css(m):
		css=m.group(1)
		l,s=parse_css_link(css,proc)
		links.update(l)
		return m.group(0).replace(css,s)
	html=patterns["inline_css"].sub(sub_css,html)
	html=patterns["html_style_attr"].sub(sub_css,html)

	if proc_script:
		patterns['inline_script'].sub(lambda m:proc_script(m.group(1)),html)

	def pool_link(m):
		s1=m.group(0)
		s2=m.group(1)
		result=patterns["html_url"].findall(s2)
		if not result:
			return s1
		if not proc:
			links.update(set(result))
			return s1
		presult=[]
		for url in result:
			purl=proc(url)
			if purl:
				presult.append(purl)
				s1=s1.replace(url,purl)
		links.update(set(presult))
		return s1



	html=patterns["html_tag"].sub(pool_link,html)
	return links,html

def parse_link(text,base_link):
	full_pattern=compile_link(base_link)
	_spool=set()
	def spool(m):
		m=m.group(0)
		if m:
			f=full_pattern.findall(m)
			if f:
				_spool.update(f)

	text=patterns['normal_url'].sub(spool,text)
	return _spool

def compile_link(base_link):
	"""
	compile_link(base_link)
	compile a regexp with base_link-match
	"""
	link_dict=parseurl(base_link,True)
	link_dict=dict(zip(link_dict.keys(),map(re.escape,link_dict.values())))
	full_pattern=re.compile(link_dict['scheme']+r'\:\/\/[^\/\\]*'+link_dict['domain']+r'(?:\:\d+)?'+link_dict['path']+r'[^\n\r*(){}\[\]"\'<>]*',re.DOTALL|re.I)
	return full_pattern





if __name__ == '__main__':
	main()
