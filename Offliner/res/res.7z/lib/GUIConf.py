#!/usr/bin/env python
# -*- coding: utf-8 -*-
#:GUIConf.py
import cPickle,os
from PathConf import path_conf

__all__=['get_lang','ini_parse','get_gui_conf','save_gui_conf']


def main():
	print get_gui_conf()
	return 0

def ini_parse(file):
	data={}
	group=None
	text=open(file,'r')
	for line in text:
		line=line.strip()
		if line and line[0]=='[':
			group=data[line[1:-1]]={}
		elif '=' in line and group !=None:
			t=line.split('=')
			group[t[0].strip()]=t[1].strip()
	return data





example_gui_conf={
"projects_record":['''../jobs'''],
"lang":'zh_CN'
}


def get_gui_conf():
	'''
	try:
		return cPickle.load(open(path_conf['gui_conf']))
	except:
		save_gui_conf(example_gui_conf)
		return example_gui_conf
	'''
	return cPickle.load(open(path_conf['gui_conf']))

def save_gui_conf(conf):
	cPickle.dump(conf,open(path_conf['gui_conf'],'w'))
	return conf


gui_conf=get_gui_conf()
default_lang_name=gui_conf['lang']

def get_lang(name=default_lang_name):
	file=path_conf['lang_path']+name+'.ini'
	if not os.path.isfile(file):
		return get_lang()
	else:
		return ini_parse(file)








if __name__ == '__main__':
	main()
