#!/usr/bin/env python
# -*- coding: utf-8 -*-
#:WGetter.py
from ExtPython import *
from xml.dom.minidom import parse as parse_xmlfile,parseString as parse_xmlstr
import os,re,cPickle
from PathConf import path_conf


__all__=['make_conf','get_conf','make_default_conf','get_default_conf','xmltodict','inner_xml']

def main():
	print default_conf

	return 0





def get_conf(path):
	path+=path_conf['conf_dump']
	if os.path.isfile(path):
		config=cPickle.load(open(path))
	else:
		config=default_conf

	return config

def make_conf(path,config=None):
	if not config:
		path=make_default_conf(path)
	else:
		path+=path_conf['conf_dump']
		cPickle.dump(config,open(path,'w'))
	return path


def make_default_conf(path):
	#from distutils.file_utils import copy_file
	import shutil
	path=path+path_conf['conf_dump']
	shutil.copy(path_conf['default_conf_dump'],path)
	return path



def get_default_conf():
	xml_file=path_conf['default_conf_xml']
	dump_file=path_conf['default_conf_dump']
	if os.path.isfile(dump_file):
		try:
			config=cPickle.load(open(dump_file))
		except:
			os.remove(dump_file)
			return get_default_conf()
	elif os.path.isfile(xml_file):
		xml=parse_xmlfile(xml_file)
		config=xmltodict(xml.documentElement)
		config['date']=dateval(xml.documentElement.getAttribute('date'))
		cPickle.dump(config,open(dump_file,'w'))
	else:
		raise Exception,'DefaultConfFileNotFound:%s'%xml_file

	return config



def xmltodict(xml,d={}):
	children=xml.childNodes
	children=filter(lambda n:n.nodeType==1,children)
	type_list={'int':intval,'bool':boolval}
	for node in children:
		nn=node.nodeName
		if not node.getElementsByTagName('*'):
			if not node.hasAttribute('vtype'):
				fc=node.firstChild
				d[nn]=fc.nodeValue if fc else ''
			else:
				t=node.getAttribute('vtype')
				d[nn]=type_list.get(t,int)(inner_xml(node))
		else:
			d[nn]={}
			xmltodict(node,d[nn])
	return d

def inner_xml(node,encoding=None):
	if not node.firstChild:
		return ''
	else:
		children=filter(lambda n:n.nodeType!=3 or n.nodeValue.strip(),node.childNodes)
		return ''.join(map(lambda n:n.toxml(),children))





default_conf=get_default_conf()

if __name__ == '__main__':
	main()
