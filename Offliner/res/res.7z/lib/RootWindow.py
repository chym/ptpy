#!/usr/bin/env python
# -*- coding: utf-8 -*-
#:RootWindow.py
from Tkinter import *
import Pmw,webbrowser,os
from ExtPython import *
from PathConf import *
from GUIConf import *
from GUIKit import *
from ConfUtils import *
from ConfEditor import *
from FileUtils import *
from WGet import *
from urllib import urlopen,quote_plus
from copy import deepcopy
import tkMessageBox as MsgBox,shutil,tkSimpleDialog as tkSD,time
import encodings

__all__=['RootWindow']


def main():
	RootWindow()
	return 0

lang=get_lang()

class RootWindow(Object):
	def __init__(self):
		self.default_conf=get_default_conf()
		self.gui_conf=get_gui_conf()
		self.cur_selected_project_index=None
		self.load_projects()
		#self.lock_log=False #Log更新锁



		self.root=root=Tk()
		Pmw.initialise()
		root.title(lang['MAIN']['NAME'])
		root.geometry('800x600')
		self.init_menu_bar()
		self.init_tool_bar()
		self.init_main_frame()
		self.init_project_list()
		self.init_msg_window()
		self.about_dialog=None
		root.protocol('WM_DELETE_WINDOW',self.exit)
		#self.interval=setInterval(self.update_msg_window,1)
		root.mainloop()

	def init_menu_bar(self):
		lm=lang['MENU']
		mbf=self.menu_bar_frame=Frame(self.root,relief=RAISED,borderwidth=1)
		mbf.pack(side=TOP,fill=X,anchor=N,expand=0)

		self.menus={}
		items=[('NEW',self.new_project),
			   ('IMPORT',self.import_project),
			   ('EXPORT',self.export_project),
			   '-',
			   ('DELETE',self.delete_selected_project),
			   ('RENAME',self.rename_selected_project),
			   '-',
			   ('EXIT',self.exit)]
		self.menus['FILE']=self.create_normal_menu('FILE',items,self.listen_file_menu)

		items=[('START',self.start_selected_project),
			   ('STOP',self.stop_selected_project),
			   '-',
			   ('START_ALL',self.start_all_projects),
			   ('STOP_ALL',self.stop_all_projects)]
		self.menus['DOWNLOAD']=self.create_normal_menu('DOWNLOAD',items,self.listen_file_menu)



		ld=lang['DIALOG']
		items=[(ld['BASIC_CONFIG'],self.show_basic_config),
			   (ld['FILE_TYPE_FILTER'],self.show_file_type_filter_config),
			   (ld['PATH_FILTER'],self.show_path_filter_config),
			   (ld['PERFORMANCE_CONFIG'],self.show_performance_config),
			   (ld['OTHER_OPTION'],self.show_other_config),
			   '-',
			   ('DEFAULT_SETTING',self.show_default_config)]
		self.menus['SETTING']=self.create_normal_menu('SETTING',items,self.listen_setting_menu)


		items=[('SHOW_HELP',self.show_help),
			   ('WEBSITE',self.open_website),
			   ('REPORT_BUGS',self.report_bugs),
			   '-',
			   ('ABOUT',self.show_about)]

		self.menus['HELP']=self.create_normal_menu('HELP',items)

		return self


	def create_normal_menu(self,text,items,postcommand=None,mb_args={}):
		lm=lang['MENU']
		mb=Menubutton(self.menu_bar_frame,text=lm[text],**mb_args)
		mb.pack(side=LEFT,ipadx=10)
		m=Menu(mb,postcommand=postcommand)
		for i in items:
			if i=='-':
				m.add('separator')
			else:
				m.add_command(label=lm[i[0]] if lm.has_key(i[0]) else i[0],command=i[1])
		mb['menu']=m
		return mb,m

	def init_tool_bar(self):
		lm=lang['MENU']
		self.toolbuttons={}
		tb=self.toolbar=Frame(self.root,relief=RAISED,borderwidth=1)
		tb.pack(side=TOP,fill=X,anchor=N,expand=0)
		items=[
		('NEW',self.new_project),
		('IMPORT',self.import_project),
		('EXPORT',self.export_project),
		('SETTING',self.config_project),
		('DELETE',self.delete_selected_project),
		('START',self.start_selected_project),
		('STOP',self.stop_selected_project),
		('VIEW',self.view_selected_project),
		('CLEAR_CONSOLE',self.clear_console)
		]
		for i in items:
			btn=Button(tb,text=lm[i[0]],command=i[1],state=DISABLED)
			btn.pack(side=LEFT,anchor=W,padx=5,pady=5,expand=0)
			self.toolbuttons[i[0]]=btn

		self.toolbuttons['NEW'].configure(state=NORMAL)
		self.toolbuttons['IMPORT'].configure(state=NORMAL)
		self.toolbuttons['CLEAR_CONSOLE'].configure(state=NORMAL)



	def init_main_frame(self):
		f=Frame(self.root,relief=GROOVE,borderwidth=1)
		f.pack(side=TOP,anchor=N,fill=BOTH,expand=1)
		self.main_frame=f
		f=Pmw.PanedWidget(self.main_frame,orient=HORIZONTAL)
		f.add('left',min=180)
		f.add('right',min=200)
		f.pack(fill=BOTH,expand=1,side=TOP)
		self.left_frame=f.pane('left')
		self.right_frame=f.pane('right')


	def init_project_list(self):
		lb=self.project_list_box=Pmw.ScrolledListBox(
			self.left_frame,listbox_selectmode=SINGLE,
			items=self.get_record_projects(),vscrollmode='dynamic',
			selectioncommand=self.onselect_project,
			dblclickcommand=self.start_selected_project)
		lb.pack(fill=BOTH,expand=1,side=LEFT,anchor=NW)



	def init_msg_window(self):
		mw=self.msg_window=Pmw.ScrolledText(self.right_frame,
			borderframe=1,text_padx=10,text_pady=10,text_wrap='word')
		mw.importfile(path_conf['welcome_file'])
		mw.pack(fill=BOTH,expand=1,side=LEFT,anchor=NW)
		self.logs=mw.get()

	def clear_console(self):
		self.msg_window.clear()
		self.logf=''

	def config_project(self,tab=0):
		ld=lang['DIALOG']
		lt=lang['TEXT']
		lb=self.project_list_box
		cur=lb.curselection()
		if not cur:
			return MsgBox.showerror(ld['ERROR'],lt['NONE_SELECT_PROJECT'],parent=self.root)
		index=intval(cur[0])
		project=self.projects[index]
		editor=ConfEditor(self.root,deepcopy(project.conf))
		editor.onconfirm=lambda:(self.confirm_new_conf(editor) and self.change_conf(editor,index))
		editor.notebook.tab(tab).invoke()
		editor.show()

	def change_conf(self,editor,index):
		ld=lang['DIALOG']
		lt=lang['TEXT']
		new_conf=editor.get_new_conf()
		project=self.projects[index]
		old_conf=project.conf
		if not new_conf['name']:
			MsgBox.showerror(ld['ERROR'],lt['EMPTY_PROJECT_NAME'],parent=editor.root)
			editor.notebook.tab(0).invoke()
			editor.project_name_entry.focus()
			return False
		if new_conf['name'] in self.get_project_names() and new_conf['name']!=old_conf['name']:
			MsgBox.showerror(ld['ERROR'],lt['ALREADY_EXISTS_NAME'],parent=editor.root)
			editor.notebook.tab(0).invoke()
			editor.project_name_entry.focus()
			return False

		try:
			urlopen(new_conf['url'])
		except:
			MsgBox.showerror(ld['ERROR'],lt['INVALID_URL'],parent=editor.root)
			editor.notebook.tab(0).invoke()
			editor.url_entry.focus()
			return False

		cPickle.dump(new_conf,open(old_conf['path']+'/'+path_conf['conf_dump'],'w'))
		if not os.path.samefile(old_conf['path'],new_conf['path']):
			state=project.stop_state
			if not state:
				project.stop()
			shutil.rmtree(new_conf['path'],True)
			shutil.copytree(old_conf['path'],new_conf['path'],True)
			shutil.rmtree(old_conf['path'],True)
			if not state:
				project.start()

		project.conf=new_conf
		if new_conf['name'] != old_conf['name']:
			self.redraw_project_list()
		return True


	def show_default_config(self):
		'''if not getattr(self,'default_conf_editor',None):
			w=Toplevel(self.root)
			editor=ConfEditor(w,deepcopy(self.default_conf))
			editor.onconfirm=lambda:self.confirm_new_conf(editor) and self.change_default_conf(editor)
			self.default_conf_editor=editor
			editor.root.transient(self.root)
			editor.root.update_idletasks()
			editor.show()
		else:
			w=self.default_conf_editor.root
			if w.winfo_exists():
				w.lift()
				w.focus()
			else:
				self.default_conf_editor=None
				self.show_default_config()'''

		editor=ConfEditor(self.root,deepcopy(self.default_conf))
		editor.onconfirm=lambda:self.confirm_new_conf(editor) and self.change_default_conf(editor)
		editor.show()

	def change_default_conf(self,editor):
		new_conf=editor.get_new_conf()
		cPickle.dump(new_conf,open(path_conf['default_conf_dump'],'w'))
		self.default_conf=new_conf
		reload(ConfUtils)
		return True
	def confirm_new_conf(self,editor):
		new_conf=editor.get_new_conf()
		ld=lang['DIALOG']
		lt=lang['TEXT']
		if not os.path.isdir(new_conf['path']):
			MsgBox.showerror(ld['ERROR'],lt['DIR_NOT_EXISTS'],parent=editor.root)
			editor.notebook.tab(0).invoke()
			editor.project_path_entry._entry.focus()
			return False
		if not os.access(new_conf['path'],os.W_OK):
			MsgBox.showerror(ld['ERROR'],lt['PERMISSION_DENIED'],parent=editor.root)
			editor.notebook.tab(0).invoke()
			editor.project_path_entry._entry.focus()
			return False

		return True


	def show_basic_config(self):
		self.config_project(0)
	def show_file_type_filter_config(self):
		self.config_project(1)
	def show_path_filter_config(self):
		self.config_project(2)
	def show_performance_config(self):
		self.config_project(3)
	def show_other_config(self):
		self.config_project(4)

	def show_help(self):
		webbrowser.open_new_tab(lang['INFO']['HELP_SITE'])

	def show_about(self):
		if not self.about_dialog:
			Pmw.aboutversion('0.1')
			Pmw.aboutcopyright('PL4CJ.ORG')
			Pmw.aboutcontact('499457633@qq.com')
			self.about_dialog=Pmw.AboutDialog(self.root,applicationname=lang['MAIN']['NAME'],buttons=(lang['BUTTON']['OK'],),defaultbutton=0,title=lang['MENU']['ABOUT'])
		else:
			self.about_dialog.show()

	def view_selected_project(self):
		lt=lang['TEXT']
		ld=lang['DIALOG']
		lb=lang['BUTTON']
		cur=self.project_list_box.curselection()
		if not cur:
			return MsgBox.showerror(ld['ERROR'],lt['NONE_SELECT_PROJECT'],parent=self.root)
		index=intval(cur[0])
		project=self.projects[index]
		index_file=project.archive_dir+'/index.htm'
		if not os.path.isfile(index_file):
			open(index_file,'w').write('<html><head><script type="text/javascript">location.replace("./");</script></head></html>')
		webbrowser.open_new_tab('file://'+index_file)
	def open_website(self):
		webbrowser.open_new_tab(lang['INFO']['WEBSITE'])

	def report_bugs(self):
		webbrowser.open_new_tab(lang['INFO']['REPORT_BUGS_SITE'])

	def get_record_projects(self):
		l=[]
		STOP=lang['TEXT']['STOP_STATE']
		COMPLETE=lang['TEXT']['COMPLETE_STATE']
		DOWNLOADING=lang['TEXT']['DOWNLOADING_STATE']
		for i,d in enumerate(self.projects):
			if d.conf['complete']:
				state=COMPLETE
			elif d.stop_state:
				state=STOP
			else:
				state=DOWNLOADING
			#l.append('%d. %s (%s)'%(i+1,d.conf['name'],state))
			#该死的字符编码问题没法弄了！！！CJ!
			l.append('%d. %s (%s)'%(i+1,'Project %s'%d.conf['name'],state))

		return l
	def new_project(self):
		lt=lang['TEXT']
		ld=lang['DIALOG']
		lb=lang['BUTTON']
		w=self.new_modal_dialog()
		w.title(lt['NEW_PROJECT_GUIDE'])
		g=Pmw.Group(w,tag_text=lt['ENTER_PROJECT_NAME_ETC'])
		g.pack(padx=5,pady=5,fill=BOTH,expand=1)
		ct=g.interior()
		f=Frame(ct)
		f.pack(side=TOP,padx=5,pady=5,expand=0,fill=X)
		Label(f,text=ld['PROJECT_NAME']+':').pack(side=LEFT,padx=5,pady=5,expand=0,anchor=W)

		project_name_var=StringVar()

		entry=Entry(f,textvariable=project_name_var)
		entry.pack(side=LEFT,padx=5,pady=5,expand=0,anchor=W)

		f=Frame(ct)
		f.pack(side=TOP,padx=5,pady=5,expand=0,fill=X)
		Label(f,text=ld['ADDRESS_START']+':').pack(side=LEFT,padx=5,pady=5,expand=0,anchor=W)

		project_url_var=StringVar()
		entry=Entry(f,textvariable=project_url_var)
		entry.pack(side=LEFT,padx=5,pady=5,expand=0,anchor=W)

		f=Frame(ct)
		f.pack(side=TOP,padx=5,pady=5,expand=0,fill=X)
		Label(f,text=ld['PROJECT_PLACE']+':').pack(side=LEFT,padx=5,pady=5,expand=0,anchor=W)

		project_path_var=StringVar()

		project_path_var.set(self.default_conf['path'])
		fe=FileEntry(f,text=ld["BROWSE"],variable=project_path_var,dironly=True)
		fe.pack(side=LEFT,expand=1,fill=BOTH,padx=5,pady=5)

		f=Frame(w)
		f.pack(side=TOP,padx=5,pady=5,expand=0)

		def valid_enter():
			name=project_name_var.get()
			path=project_path_var.get()
			url=project_url_var.get()
			if not (name and path and url):
				return MsgBox.showerror(ld['ERROR'],lt['EMPTY_ERROR'],parent=w)
			if name in self.get_project_names():
				return MsgBox.showerror(ld['ERROR'],lt['ALREADY_EXISTS_NAME'],parent=w)

			if not os.path.isdir(path):
				return MsgBox.showerror(ld['ERROR'],lt['DIR_NOT_EXISTS'],parent=w)

			if not os.access(path,os.W_OK):
				return MsgBox.showerror(ld['ERROR'],lt['PERMISSION_DENIED'],parent=w)

			try:
				urlopen(url)
			except:
				return MsgBox.showerror(ld['ERROR'],lt['INVALID_URL'],parent=w)
			conf=get_default_conf()
			conf['name']=name
			conf['path']=path+'/'
			conf['url']=url
			if self.add_new_project(conf):
				w.quit()
				w.destroy()
			return False

		btn=Button(f,text=lb["OK"],command=valid_enter)
		btn.pack(padx=5,pady=5,expand=0,side=LEFT)

		btn=Button(f,text=lb['CANCEL'],command=(lambda:(w.quit(),w.destroy())))
		btn.pack(padx=5,pady=5,expand=0,side=LEFT)

		w.mainloop()#necessary

	def add_new_project(self,conf):
		p=Download(conf)
		name=conf['name']
		p.index=len(self.projects)
		self.bind_project(p)
		self.projects.append(p)
		self.redraw_project_list()
		return True
	def get_project_names(self):
		names=[]
		for i in self.projects:
			names.append(i.conf['name'])
		return names

	def import_project(self):
		lt=lang['TEXT']
		ld=lang['DIALOG']
		lb=lang['BUTTON']
		w=self.new_modal_dialog()
		w.title(lt['IMPORT_PROJECT'])

		f=Frame(w)
		f.pack(side=TOP,padx=5,pady=5,expand=0,anchor=W)
		Label(f,text=ld['PROJECT_NAME']+':').pack(side=LEFT,padx=5,pady=5,expand=0,anchor=W)
		project_name_var=StringVar()
		entry=Entry(f,textvariable=project_name_var)
		entry.pack(side=LEFT,padx=5,pady=5,expand=0,anchor=W)

		f=Frame(w)
		f.pack(side=TOP,padx=5,pady=5,expand=0,anchor=W)

		Label(f,text=ld['PROJECT_PLACE']+':').pack(side=LEFT,padx=5,pady=5,expand=0,anchor=W)

		project_path_var=StringVar()

		project_path_var.set(self.default_conf['path'])
		fe=FileEntry(f,text=ld["BROWSE"],variable=project_path_var,dironly=True)
		fe.pack(side=LEFT,expand=1,fill=BOTH,padx=5,pady=5)



		f=Frame(w)
		f.pack(side=TOP,padx=5,pady=5,expand=0)

		def valid_enter():
			path=project_path_var.get()
			if not path or  not os.path.isdir(path):
				return MsgBox.showerror(ld['ERROR'],lt['DIR_NOT_EXISTS'],parent=w)

			if not os.access(path,os.W_OK):
				return MsgBox.showerror(ld['ERROR'],lt['PERMISSION_DENIED'],parent=w)

			conf_file=path+'/'+path_conf['conf_dump']
			if not os.path.isfile(conf_file):
				return MsgBox.showerror(ld['ERROR'],lt['CONF_FILE_NOT_EXISTS'],parent=w)
			try :
				conf=cPickle.load(open(conf_file))
			except:
				return MsgBox.showerror(ld['ERROR'],lt['IMPORT_ERROR'],parent=w)

			name=project_name_var.get()
			if not name:
				if not conf['name']:
					return MsgBox.showerror(ld['ERROR'],lt['EMPTY_NAME'],parent=w)
				name=conf['name']
				project_name_var.set(name)
			else:
				conf['name']=name
			url=conf['url']
			conf['path']=path+'/'
			if name in self.get_project_names():
				return MsgBox.showerror(ld['ERROR'],unicode(lt['ALREADY_EXISTS_NAME'],'utf-8')+":"+name,parent=w)

			for i in self.projects:
				if os.path.samefile(conf['path'],i.conf['path']):
					return MsgBox.showerror(ld['ERROR'],unicode(lt['ALREADY_EXISTS_PROJECT'],'utf-8')+":"+i.conf['name'],parent=w)
			#try:
			#	urlopen(url)
			#except:
			#	return MsgBox.showerror(ld['ERROR'],lt['INVALID_URL'],parent=w)
			make_conf(conf['path'],conf)
			if self.add_new_project(conf):
				w.quit()
				w.destroy()
			return False

		btn=Button(f,text=lb["OK"],command=valid_enter)
		btn.pack(padx=5,pady=5,expand=0,side=LEFT)

		btn=Button(f,text=lb['CANCEL'],command=(lambda:(w.quit(),w.destroy())))
		btn.pack(padx=5,pady=5,expand=0,side=LEFT)

		w.mainloop()#necessary

	def export_project(self):
		lt=lang['TEXT']
		ld=lang['DIALOG']
		lb=lang['BUTTON']
		cur=self.project_list_box.curselection()
		if not cur:
			return MsgBox.showerror(ld['ERROR'],lt['NONE_SELECT_PROJECT'],parent=self.root)

		project=self.projects[intval(cur[0])]

		w=self.new_modal_dialog()
		w.title(lt['EXPORT_PROJECT'])

		f=Frame(w)
		f.pack(side=TOP,padx=5,pady=5,expand=0)

		Label(f,text=lt['EXPORT_PROJECT_PLACE']+':').pack(side=LEFT,padx=5,pady=5,expand=0,anchor=W)

		project_path_var=StringVar()
		project_path_var.set(self.default_conf['path'])
		fe=FileEntry(f,text=ld["BROWSE"],variable=project_path_var,dironly=True)
		fe.pack(side=LEFT,expand=1,fill=BOTH,padx=5,pady=5)
		f=Frame(w)
		f.pack(side=TOP,padx=5,pady=5,expand=0)
		def valid_enter():
			path=project_path_var.get()
			if not path or  not os.path.isdir(path):
				return MsgBox.showerror(ld['ERROR'],lt['DIR_NOT_EXISTS'],parent=w)
			if os.path.samefile(path,project.conf['path']):
				return MsgBox.showerror(ld['ERROR'],lt['DIR_IS_SAME'],parent=w)
			if not os.access(path,os.W_OK):
				return MsgBox.showerror(ld['ERROR'],lt['PERMISSION_DENIED'],parent=w)

			conf=project.conf
			shutil.copy(conf['path']+'/'+path_conf['conf_dump'],path+'/'+path_conf['conf_dump'])
			shutil.copy(project.url_all_file,path+'/'+path_conf['url_all'])
			shutil.copy(project.url_nocomplete_file,path+'/'+path_conf['url_nocomplete'])
			shutil.copy(project.url_complete_file,path+'/'+path_conf['url_complete'])
			w.quit()
			w.destroy()
			MsgBox.showinfo(ld['INFO'],lt['PROJECT_EXPORT_SUCCESS'],parent=self.root)
			return False

		btn=Button(f,text=lb["OK"],command=valid_enter)
		btn.pack(padx=5,pady=5,expand=0,side=LEFT)

		btn=Button(f,text=lb['CANCEL'],command=(lambda:(w.quit(),w.destroy())))
		btn.pack(padx=5,pady=5,expand=0,side=LEFT)

		w.mainloop()#necessary

	def delete_selected_project(self):
		lt=lang['TEXT']
		ld=lang['DIALOG']
		lb=lang['BUTTON']
		cur=self.project_list_box.curselection()
		if not cur:
			return MsgBox.showerror(ld['ERROR'],lt['NONE_SELECT_PROJECT'],parent=self.root)

		project=self.projects[intval(cur[0])]

		w=self.new_modal_dialog()
		w.title(lt['DELETE_PROJECT'])
		Label(w,text=lt['IF_DELETE_PROJECT']).pack(side=TOP,padx=10,pady=10,expand=0,anchor=N)

		if_del_conf=BooleanVar()
		if_del_conf.set(True)
		Checkbutton(w,text=lt['DELETE_CONF_FILE'],variable=if_del_conf).pack(padx=10,pady=5,side=TOP,anchor=NW)

		if_del_dir=BooleanVar()
		if_del_dir.set(False)
		Checkbutton(w,text=lt['DELETE_PROJECT_DIR'],variable=if_del_dir).pack(padx=10,pady=5,side=TOP,anchor=NW)

		f=Frame(w)
		f.pack(side=TOP,padx=10,pady=10,expand=0)
		def delete_call():
			del_conf=if_del_conf.get()
			del_dir=if_del_dir.get()
			i=intval(cur[0])
			project=self.projects[i]
			project.stop()
			path=project.conf['path']
			if del_conf and not del_dir:
				os.remove(path+'/'+path_conf['conf_dump'])
				os.remove(project.url_all_file)
				os.remove(project.url_complete_file)
				os.remove(project.url_nocomplete_file)
			if del_dir:
				shutil.rmtree(path,True)
			self.project_list_box.delete(i)
			del self.projects[i]
			w.quit()
			w.destroy()
		btn=Button(f,text=lb["YES"],command=delete_call)
		btn.pack(padx=5,pady=5,expand=0,side=LEFT)

		btn=Button(f,text=lb['NO'],command=(lambda:(w.quit(),w.destroy())))
		btn.pack(padx=5,pady=5,expand=0,side=LEFT)

		w.mainloop()#necessary

	def rename_selected_project(self):
		lt=lang['TEXT']
		ld=lang['DIALOG']
		lb=lang['BUTTON']
		cur=self.project_list_box.curselection()
		if not cur:
			return MsgBox.showerror(ld['ERROR'],lt['NONE_SELECT_PROJECT'],parent=self.root)
		index=intval(cur[0])
		project=self.projects[index]
		flag=True
		while flag:
			new_name=tkSD.askstring(ld['RENAME'],lt['ENTER_NEW_NAME'])
			if new_name and new_name in self.get_project_names():
				if new_name==project.conf['name']:
					return False
				MsgBox.showerror(ld['ERROR'],lt['ALREADY_EXISTS_NAME'],parent=self.root)
			else:
				flag=False
		if not new_name:
			return False
		project.conf['name']=new_name
		#self.project_list_box.setlist(self.get_record_projects())
		project.save_conf()
		self.redraw_project_list()


	def onselect_project(self):
		lb=self.project_list_box
		sitems=lb.curselection()
		if not sitems:
			return False
		index=intval(sitems[0])
		btns=['EXPORT','DELETE','SETTING','START','STOP','VIEW']
		for i in btns:
			self.toolbuttons[i].configure(state=NORMAL)
		project=self.projects[index]
		if project.stop_state:
			self.toolbuttons['STOP'].configure(state=DISABLED)


	def start_selected_project(self,index=None):
		lt=lang['TEXT']
		ld=lang['DIALOG']
		lb=lang['BUTTON']
		if index==None:
			cur=self.project_list_box.curselection()
			if not cur:
				return MsgBox.showerror(ld['ERROR'],lt['NONE_SELECT_PROJECT'],parent=self.root)
			index=intval(cur[0])
		project=self.projects[index]
		if project.isfinish():
			if not MsgBox.askyesno(ld['INFO'],lt['ALREADY_COMPLETE']+"\n"+project.conf['name'],parent=self.root):
				return False
			else:
				project.reset()
		if not project.start():
			return MsgBox.showerror(ld['ERROR'],lt['PROJECT_START_FAIL']+"\n"+project.conf['name'],parent=self.root)
		self.report_project_start(index)
		self.redraw_project_list()

	def stop_selected_project(self,index=None):
		lt=lang['TEXT']
		ld=lang['DIALOG']
		lb=lang['BUTTON']
		if index==None:
			cur=self.project_list_box.curselection()
			if not cur:
				return MsgBox.showerror(ld['ERROR'],lt['NONE_SELECT_PROJECT'],parent=self.root)
			index=intval(cur[0])
		project=self.projects[index]
		project.stop()
		self.redraw_project_list()
		self.report_project_stop(index)

	def start_all_projects(self):
		for i in range(len(self.projects)):
			self.start_selected_project(index=i)

	def stop_all_projects(self):
		for i in range(len(self.projects)):
			self.stop_selected_project(index=i)
	def redraw_project_list(self):
		self.project_list_box.setlist(self.get_record_projects())

	def report_project_start(self,index):
		project=self.projects[index]
		self.add_log(lang['MENU']['PROJECT']+':'+project.conf['name']+"\t"+lang['TEXT']['START_UP'])
		return
	def report_project_stop(self,index):
		project=self.projects[index]
		self.add_log(lang['MENU']['PROJECT']+':'+project.conf['name']+"\t"+lang['MENU']['STOP'])
		return
	def report_project_complete(self,index):
		project=self.projects[index]
		lt=lang['TEXT']
		text=lang['MENU']['PROJECT']+':'+project.conf['name']+"\t"+lt['COMPLETE_STATE']+"\n"
		text+=lt['FILE_COUNT']+':'+str(project.conf['file-count'])+"\n"
		text+=lt['DISK_USEAGE']+":%.2d KB\n"%(project.conf['disk-useage']/1024)
		text+=lt['URL_COUNT']+':'+str(len(project.url_complete.keys()))
		self.add_log(text)

		self.redraw_project_list()
		project.save_url()
		project.save_conf()
		if project.conf['auto-prompt-oncomplete']:
			info=lt['COMLETE_NOTICE']+"\n"+project.conf['name']
			MsgBox.showinfo(lang['DIALOG']['INFO'],info,parent=self.root)
		return
	def report_thread_start(self,index,thread_num,url,url_info):
		return
		project=self.projects[index]
		lt=lang['TEXT']
		text=lang['MENU']['PROJECT']+':'+project.conf['name']+"\n"
		text+=lt['THREAD']+str(thread_num)+"\t\t"+lt['PROCESSING']+":\t" + url
		self.add_log(text)
		return
	def report_thread_wait(self,index,thread_num):
		return
		project=self.projects[index]
		lt=lang['TEXT']
		text=lang['MENU']['PROJECT']+':'+project.conf['name']+"\n"
		text+=lt['THREAD']+str(thread_num)+"\t\t"+lt['WAIT']
		self.add_log(text)
		return
	def report_thread_finish(self,index,thread_num,url,url_info):
		return
		project=self.projects[index]
		lt=lang['TEXT']
		text=lang['MENU']['PROJECT']+':'+project.conf['name']+"\n"
		text+=lt['THREAD']+str(thread_num)+"\t\t"+lt['PROCESSED']+":\t" + url
		self.add_log(text)
		return

	def add_log(self,text):
		#while self.lock_log:
		#	sleep(1)
		#self.lock_log=True
		t=self.logs
		t="\n"+unicode(text,'UTF-8')+"\n"+self.timestamp()+"\n\n"+t
		self.logs=t
		self.msg_window.settext(self.logs)
		#self.lock_log=False
		return



	def load_projects(self):
		self.projects=[]
		projects_list=self.gui_conf['projects_record']
		filter_projects=[]
		rewrite=False
		for i,v in enumerate(projects_list):
			if not v or  not os.path.isdir(v):
				projects_list[i]=None
				rewrite=True
			else:
				filter_projects.append(v)
				c=get_conf(v)
				p=Download(c)
				p.index=len(self.projects)
				self.bind_project(p)
				self.projects.append(p)

		if rewrite:
			self.gui_conf['projects_record']=filter_projects
			self.save_gui_conf()


	def save_gui_conf(self):
		l=[]
		for p in self.projects:
			p.stop()
			p.save_url()
			p.save_conf()
			l.append(p.conf['path'])

		self.gui_conf['projects_record']=l
		save_gui_conf(self.gui_conf)
		return self


	def bind_project(self,p):
		p.oncomplete=self.report_project_complete
		p.report_start=self.report_thread_start
		p.report_wait=self.report_thread_wait
		p.report_finish=self.report_thread_finish
		return p

	def exit(self):
		self.save_gui_conf()
		self.root.quit()
		self.root.destroy()

	def new_modal_dialog(self,onclose=None):
		w=Toplevel(self.root)
		w.protocol('WM_DELETE_WINDOW',onclose or (lambda:(w.quit(),w.destroy())) )
		w.transient(self.root)
		w.update_idletasks()
		w.wait_visibility()
		w.deiconify()
		w.grab_set()
		w.resizable(False,False)
		return w

	def listen_file_menu(self):
		a=self.project_list_box.curselection()
		mb,m=self.menus['FILE']
		if not a:
			state=DISABLED
		else:
			state=NORMAL
		for i in (3,5,6):
			m.entryconfigure(i,state=state)

	def listen_setting_menu(self):
		a=self.project_list_box.curselection()
		mb,m=self.menus['SETTING']
		if not a:
			state=DISABLED
		else:
			state=NORMAL
		for i in (1,2,3,4,5):
			m.entryconfigure(i,state=state)

	def listen_file_menu(self):
		cur=self.project_list_box.curselection()
		mb,m=self.menus['DOWNLOAD']

		if not cur:
			m.entryconfigure(1,state=DISABLED)
			m.entryconfigure(2,state=DISABLED)
		else:
			index=intval(cur[0])
			project=self.projects[index]
			if project.stop_state:
				m.entryconfigure(2,state=DISABLED)
				m.entryconfigure(1,state=NORMAL)
			else:
				m.entryconfigure(1,state=DISABLED)
				m.entryconfigure(2,state=NORMAL)




	def timestamp(self):
		return time.strftime('%Y-%m-%d %H:%M:%S')







if __name__ == '__main__':
	main()
