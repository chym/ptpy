#!/usr/bin/env python
# -*- coding: utf-8 -*-
#:PageCompressor.py
import re
try:
        from curses.ascii import isalnum
except:
        def isalnum(s):
                return patterns['alnum'].match(s)

__all__=['comment_strip_html','comment_strip_css','comment_strip_js','compress_html','compress_css','compress_js']

def main():
	print "PageCompressor Test Here!!!"
	#js=open("tmp/base.js","r").read()
	#print patterns['string'].findall(comment_strip_js(js))
	js='''
function _import(jsFile,basePath)
{
	 var head = document.getElementsByTagName('HEAD').item(0);
	 var script = document.createElement('SCRIPT');
	 if (basePath == undefined)
	 {
		 basePath = ImportBasePath;
	 }

	 jsFile = basePath + jsFile.replace(/\./g, '/') + '.js';

	 script.src = jsFile;
	 script.type = "text/javascript";
	 head.appendChild(script);
 }
	'''
	print compress_js(js)
	return 0


patterns={
	'html_comment':re.compile(r'<!--.*?(?<!//)-->',re.DOTALL),
	'html_space':re.compile(r'>\s+<'),
	'mulspace':re.compile(r'\s{2,}'),
	'start_space':re.compile(r'^\s+'),
	'empty_line':re.compile(r'^\s*$'),
        'alnum':re.compile(r'[:alnum:]'),
	'endline':re.compile(r'\s*(;|{|})\s*\n\s*',re.M),
	'endline2':re.compile(r';\s*}',re.M),
	'css_in_html':re.compile(r'(<style(?:\s[^>]+)?>)([^<]+)(</style>)',re.I),
	'js_in_html':re.compile(r'(<script(?:\s[^>]+)?>)(.*?)(</script>)',re.I|re.DOTALL),
	'string':re.compile(r'(\'|")((?:.*?)(?<!\\)(?:\\\\)*)\1',re.DOTALL),
	'string_queue':re.compile(r'&(\d+)#'),
	'js':re.compile(r'(?:\s*\/\/[^\n\r]*)',re.DOTALL),
}

def comment_strip_html(html):
	"""
	comment_strip_html(text)
	remove the comment in html text
	"""
	return patterns['html_comment'].sub('',html)

def comment_strip_css(css):
	"""
	comment_strip_css(css)
	remove the comment in css text
	"""
	return __comment_strip(css,False)

def comment_strip_js(js):
	"""
	comment_strip_js(js)
	remove the comment in javascript text
	"""
	js= __comment_strip(js,True)
	js=js.split("\n")
	ret=[]
	for line in js:
		line=line.strip()
		if line:
			ret.append(line)
	return "\n".join(ret)


def __comment_strip(text,single=True):
	"""
	__comment_strip(text,single)
	remove the comment in text,such as "/*Comment*/" and "//Comment"
	@param single boolean toogle if need remove the single line comment
	"""
	incomment=instring=inscomment=False
	qoutes=["'",'"','/']
	last_qoute=None
	ret=[]
	ens=enumerate(text)
	text_max=len(text)-1
	for i,c in ens:
		if incomment:
			if c=='/' and text[i-1]=='*':
				incomment=False
		elif inscomment:
			if c=='\n':
				inscomment=False
				ret.append(c)
		elif instring:
			ret.append(c)
			if c ==last_qoute:#lookup
				count=1
				while text[i-count]=='\\':
					count+=1
				if count % 2:
					instring=False
		elif single and c=='/' and i<text_max and text[i+1] =='/':
			inscomment=True
		elif c=='/' and i<text_max and text[i+1]=='*':
			incomment=True
			if i<text_max-1:
				ens.next()
				ens.next()
		elif c in qoutes:
			instring=True
			if c =='/':
				t=i-1
				while t and text[t] in " \t\n\r":
					t-=1
				if isalnum(text[t]):#is a varname or 3/4 etc.
					instring=False

			last_qoute=c
			ret.append(c)
		else:
			ret.append(c)
	return	"".join(ret)

def compress_js(js):
	"""
	compress_js(js)
	compress the javascript source code.remove comment,space
	"""
	spool=[]
	js=comment_strip_js(js)
	#js=__spool_string(js,spool)
	#js=__fix_endline(js)
	#return __depool_string(js,spool).strip()
	return js.strip();

def compress_css(css):
	"""
	compress_css(css)
	compress the css source code.remove comment,space
	"""
	spool=[]
	if '/*' in css and '*/' in css:
		css=comment_strip_css(css)

	if '"' in css or "'" in css:
		css=__spool_string(css,spool)

	css=__fix_endline(css)

	return __depool_string(css,spool).strip()

def compress_html(html):
	"""
	compress_html(html):
	compress the html text.remove comment,space,also can compress the inline css,js code
	"""

	html=patterns['html_space'].sub('><',html)
	if '<style' in html:
		html=patterns['css_in_html'].sub(__compress_in_html(compress_css),html)
	if '<script' in html:
		html=patterns['js_in_html'].sub(__compress_in_html(compress_js),html)

	html=comment_strip_html(html)

	return html.strip()


def __compress_in_html(func):
	def callback(m):
		return m.group(1)+func(m.group(2))+m.group(3)
	return callback

def __spool_string(text,spool):
	def callback(matches):
		spool.append(matches.group(0))
		return '&%d#'%(len(spool)-1)
	return patterns['string'].sub(callback,text)

def __depool_string(text,spool):
	if not len(spool):
		return text
	def callback(m):
		return spool[int(m.group(1))]
	return patterns['string_queue'].sub(callback,text)

def __fix_endline(text):
	text=patterns['endline'].sub(r'\1',text)
	text=patterns['endline2'].sub('}',text)
	text=patterns['mulspace'].sub(' ',text)
	return text



if __name__ == '__main__':
	main()
