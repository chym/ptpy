#!/usr/bin/env python
# -*- coding: utf-8 -*-
#:WGet.py
from ExtPython import *
from FileUtils import *
from LinkParser import *
from PageCompressor import *
from urlparse import urljoin
from time import sleep
from urllib import urlretrieve,quote,unquote
import ConfUtils,cPickle,threading,os
from ConfUtils import *
from copy import deepcopy
from PathConf import path_conf
import sys
#sys.stdout=open('log.txt','w')

def main():
	config=ConfUtils.default_conf
	#config['path-depth']=1
	#config['path-filter']['deny']='/base/,/index/'
	#config['path-filter']['allow']='/base/,/index/'
	config['url']='http://localhost/windowsapache/ThinkPHP/Examples/'
	config['max-thread']=20
	config['file-count-max']=0
	#config['file-size-max']=1
	#print config['url']
	#config['compress-js']=config['compress-css']=config['compress-html']=False
	d=Download(config)
	print d.start()
	return 0

	config=ConfUtils.default_conf #获取默认配置
	config['path-depth']=1 #配置目录深度
	config['path-filter']['deny']='/base/,/index/' #阻止下载的路径
	config['path-filter']['allow']='/base/,/index/' #允许下载的路径
	config['url']='http://localhost/'#下载指定的URL（即网站地址）
	config['max-thread']=20 #最大线程数
	config['file-count-max']=0 #下载的最大文件数,0表示不限制
	config['file-size-max']=0 #下载的单个文件最大大小，0表示不限制

	#配置是否压缩下JS,CSS及HTML文件（去除多余的空白）
	config['compress-js']=config['compress-css']=config['compress-html']=True


	d=Download(config) #创建下载实例
	print d.start() #开始下载,start方法返回True表示成功开始



class Download(Object):
	"""
	Download __init__(self,conf=ConfUtils.default_conf)
	@TODO	conf.disk_useage 每下载一个文件，将文件大小追加到此变量中
			conf.file_count	每下载一个文件，file_count+=1
			url_dict	一个绝对的URL为键，值为list,依次为
			(其在目录中的绝对路径(archive_dir为根目录),MIME,EXT_NAME,BASE_NAME,LOCK_FLAG)
	"""
	index=0
	def __init__(self,conf=ConfUtils.get_default_conf):
		self.conf=conf
		self.stop_state=True
		self.start_url=realurl(conf['url'])
		self.start_url_parsed=parseurl(conf['url'])
		self.base_urlpath=self.start_url_parsed['path']

		self.archive_dir=conf['path']+path_conf['archive_dir']

		self.compress_html=compress_html if conf['compress-html'] else lambda x:x
		self.compress_js=compress_js if conf['compress-js'] else lambda x:x
		self.compress_css=compress_css if conf['compress-css'] else lambda x:x

		#self.interval=None #thread start forestall
		#self.interval=setInterval(self.progress_monitor,10)

		self.init_file()


	def start(self):
		conf=self.conf
		self.stop_state=False
		if self.isfinish():
			return False


		if conf['auto-backup']:
			self.backup()


		ret=self.download(self.start_url)
		if not ret:
			return False
		self.url_all=ret
		self.url_nocomplete=ret.copy()#一个浅Copy

		max_th=conf['max-thread']
		if max_th<1 or max_th >1000:
			conf['max-thread']=10 #如果线程数不是合法的数字，则重置
			self.save_conf()
		self.threads=[]
		while max_th>0:
			max_th-=1
			th=setTimeout(lambda i=len(self.threads):self.run(i),timeout=1)
			self.threads.append(th)


		return self


	def run(self,i):
		conf=self.conf
		if self.stop_state:
			return False
		if self.isfinish():
			self.stop()
			self.oncomplete(self.index)
			return False
		if not self.url_nocomplete:
			conf['complete']=True
			return False


		queue=self.url_nocomplete.copy()
		url=url_info=3 #magic number
		for k in queue:
			if queue[k][-1]:
				if self.url_complete.has_key(k):
					del self.url_nocomplete[k]
				continue
			else:
				url=k
				url_info=queue[k]
				url_info[-1]=True #Lock it!!!
				break




		if url==3 and url_info==3 and not conf['complete'] and not self.stop_state:#Busy now!!!
			if self.conf['complete'] or self.stop_state:
				return False

			self.report_wait(self.index,i)
			self.threads[i]=setTimeout(lambda i=i,self=self:self.run(i),1)
			return False


		self.report_start(self.index,i,url,url_info) #报告进度

		self.parse_page(url,url_info)
		url_info[-1]=False
		if self.url_nocomplete.has_key(k):
			self.url_nocomplete[url][-1]=False
			del self.url_nocomplete[url]#complete one

		self.url_complete[url]=url_info

		self.report_finish(self.index,i,url,url_info) #报告结束处理

		self.threads[i]=setTimeout(lambda i=i,self=self:self.run(i),1) #Go on




		return False

	def download(self,rurl):
		if self.url_complete.has_key(rurl):#if already downloaded
			return {rurl:self.url_complete[rurl]}


		if self.isfinish() or self.stop_state:
			return False

		f=None
		retry_times=self.conf['retry']
		while not f and not self.stop_state:
			try:
				f=RemoteFile(rurl)
				if f.getcode() in (408,503) : #408是请求超时，503是服务器超载
					sleep(self.conf['timeout'])
					retry_times-=1
					if retry_times<0:return False
			except:
				break


		if not f or not (200<= f.getcode() <=300):
			return False


		fname=os.path.basename(rurl)
		if not fname:
			fname='index'+'.'+f.getextname()
		else:
			dotpos=fname.rfind('.')
			if dotpos > -1:
				fname=fname[0:dotpos]
			fname+='.'+f.getextname()
		purl=parseurl(rurl)
		start_pos=purl['path'].find(self.base_urlpath)
		if start_pos > -1:
			fpath=purl['path'][start_pos+len(self.base_urlpath):].strip('/')
		else:
			fpath=purl['path'].strip('/')
		if fpath:
			fpath='/'+fpath+'/'
		fpath=quote(fpath+fname)
		wfpath=self.archive_dir+fpath

		if not os.path.isfile(wfpath):
			wfp=os.path.dirname(wfpath)
			if not os.path.isdir(wfp):
				os.makedirs(wfp)
			f.retrieve(wfpath)
			self.conf['file-count']+=1
			self.conf['disk-useage']+=f.getsize()
		return {rurl:[fpath,f.getmime(),f.getextname(),fname,f.getsize(),False]}


	def parse_page(self,url,url_info):
		mime=url_info[1]
		if mime not in ['text/html','application/xml','text/xml','text/css','application/javascript','text/javascript','application/xhtml+xml']:
			return False
		conf=self.conf
		sitepath=url_info[0]
		curpath=os.path.dirname(sitepath)+'/'
		filepath=self.archive_dir+sitepath
		content=open(filepath,'r').read()



		def proc(m):
			rurl=self.valid_url(m,url)
			if not rurl:
				return False
			durl=self.download(rurl)

			if not durl:
				return False
			self.add_url(durl)
			if '://' in m or m[0]=='/':
				return quote(relative_path(durl[rurl][0],curpath))
			else:
				dirname=os.path.dirname(m)
				if dirname:
					dirname+='/'
				return quote(dirname + os.path.basename(durl[rurl][0]))

		def sub_script(m):
			rurl=self.valid_url(m,url)
			if not rurl:
				return False
			durl=self.download(rurl)
			script=open(self.archive_dir+durl[rurl][0]).read()
			parse_js_link(script,proc)
		if mime in ['text/html','text/xml','application/xml']:
			parser=lambda html,proc:parse_html_link(html,proc,proc_script=sub_script)
			compressor=self.compress_html
		elif mime in ['text/css']:
			parser=parse_css_link
			compressor=self.compress_css
		elif mime in ['text/javascript','application/javascript']:
			parser=parse_js_link
			compressor=self.compress_js
		else:
			return
		links,content=parser(content,proc)
		open(filepath,'w').write(compressor(content))
		return

	def valid_url(self,url,cur):
		conf=self.conf
		spurl=parseurl(conf['url'])
		if not samedomain(spurl['domain'],url):#是否在相同域
			return False
		if conf['deny-ftp'] and url.startswith('ftp://'):#是否下载FTP文件
			return False

		if conf['filetype-filter']['deny-noextname'] and  not extname(url):#是否不下载没有扩展名的文件
			return False

		if extname(url) and extname(url) in conf['filetype-filter']['deny-extname']:#被阻止的扩展名
			return False

		jurl=urljoin(cur,url)

		rurl=realurl(jurl,domain=spurl['domain'],scheme=spurl['scheme'])
		purl=parseurl(rurl)




		t=conf['path-depth']
		if t and len(purl['path'].split('/'))-2 > t:#目录层次深度限制
			return False

		t=conf['path-filter']['allow']
		if t and t!='/':#不在允许路径范围内
			for p in t.split(','):
				if purl['path'].startswith(p):
					break
			else:
				return False
		t=conf['path-filter']['deny']
		if t:#被阻止的路径
			for p in t.split(','):
				if purl['path'].startswith(p):
					return False


		try:#if any error occurred,return False
			f=RemoteFile(rurl)
		except:
			return False
		mime=f.getmime()
		t=conf['filetype-filter']['deny-mime']
		if t and mime in t.split(','):#被阻止的MIME
			return False
		t=conf['filetype-filter']['allow-mime']
		if t and t not in ['*/*','*'] and mime not in t.split(','):#不被允许的MIME
			return False

		#未知类型MIME
		if conf['filetype-filter']['deny-unknown-mime'] and mime in ['','*','*/*','application/octet-stream']:
			return False

		if conf['file-size-max'] and f.getsize() > conf['file-size-max']: #超出指定文件大小
			return False



		return rurl


	def init_file(self):
		path=self.conf['path']
		t=path+path_conf['archive_dir']
		if not os.path.isdir(t):
			os.makedirs(t)
		#t=path+path_conf['tmp_dir']
		#if not os.path.isdir(t):
		#	os.makedirs(t)
		t=path+path_conf['conf_dump']
		if not os.path.isfile(t):
			ConfUtils.make_conf(path,self.conf)

		self.load_url()




	def save_url(self):
		cPickle.dump(self.url_all,open(self.url_all_file,'w'))
		cPickle.dump(self.url_complete,open(self.url_complete_file,'w'))
		cPickle.dump(self.url_nocomplete,open(self.url_nocomplete_file,'w'))
		return self

	def load_url(self):
		path=self.conf['path']
		t=self.url_all_file=path+path_conf['url_all']
		self.url_all=self.safe_load(t,{})
		t=self.url_complete_file=path+path_conf['url_complete']
		self.url_complete=self.safe_load(t,{})
		t=self.url_nocomplete_file=path+path_conf['url_nocomplete']
		self.url_nocomplete=self.safe_load(t,{})
		return self


	def save_conf(self,path=None):
		make_conf(path or self.conf['path'],self.conf)
		return self

	def load_conf(self,path=None):
		self.conf=ConfUtils.get_conf(path or self.conf['path'])
		return self

	def safe_load(self,f,default=None):
		data=default
		try:
			data=cPickle.load(open(f))
		except : #cPickle.UnpicklingError,IOError,EOFError
			cPickle.dump(default,open(f,'w'))

		return data

	def oncomplete(self,index):
		print 'Complete!!!'
		print '''
			DiskUsageNow:%(disk-useage)s
			DiskUseageMax:%(disk-useage-max)s
			FileCountNow:%(file-count)s
			FileCountMax:%(file-count-max)s''' % self.conf


	def report_start(self,index,i,url,url_info):
		print i,url,url_info

	def report_finish(self,index,i,url,url_info):
		print i,url,url_info

	def report_wait(self,index,i):
		print 'Wait!!!',i

	def stop(self):
		self.stop_state=True
	def add_url(self,urldict):
		for k in urldict:
			if not self.url_all.has_key(k):
				self.url_all[k]=urldict[k]
				self.url_nocomplete[k]=urldict[k]
				self.url_nocomplete[k][-1]=False
		return

	def isfinish(self):
		conf=self.conf
		if (
			conf['complete'] #已经完成
			or (conf['disk-useage-max'] and (conf['disk-useage'] >= conf['disk-useage-max'])) #容量超出限制
			or (conf['file-count-max'] and (conf['file-count'] >= conf['file-count-max'])) #文件数量超出限制
		   ):
			conf['complete']=True
			return True
		return False

	def reset(self):
		conf=self.conf
		conf['complete']=False
		conf['file-count']=conf['disk-useage']=0
		self.url_complete={}

	def progress_monitor(self):
		if not self.interval:
			return False
		if self.isfinish() or not self.url_nocomplete:
			self.interval[1]()
			self.conf['complete']=True
			self.stop_state=True
			self.interval=None

	def backup(self,dist=None):
		conf=self.conf
		import shutil
		t=dist or (conf['path']+path_conf['archive_bak_dir'])
		if os.path.isdir(t):
			shutil.rmtree(t,True)
		else:
			os.mkdir(t)
		shutil.copytree(self.archive_dir,t)
		return self

	def copyto(self,dist):
		import shutil
		shutil.copytree(self.conf['path'],dist)
		return self




if __name__ == '__main__':
	main()
