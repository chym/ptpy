#!/usr/bin/env python
# -*- coding: utf-8 -*-
#:GUIKit.py
from ExtPython import *
from subprocess import Popen,PIPE
import os,sys
__all__=['gbrowse','FileEntry','browse','tkbrowse']

from Tkinter import *
import tkFileDialog as FD
def main():
	import gtk
	w=Tk()
	var=StringVar()
	var.set("/usr/")
	FileEntry(w,var,bd=2,dironly=True).pack(padx=10,pady=10,fill=BOTH)

	w.mainloop()


	return 0



def gbrowse(filename=None,title=None,multiple=False,
			dironly=False,savemode=False,
			confirm_overwrite=True,filter=None):
	"""
	gbrowse
	file-selection in GNOME
	"""
	shargs=['zenity','--file-selection','--title=%s'%(title or 'Gtk File Selection')]
	filename and shargs.append('--filename=%s'%filename)
	multiple and shargs.append('--multiple')
	dironly and shargs.append('--directory')
	savemode and shargs.append('--save')
	#multiple and shargs.append('--separator=|')
	confirm_overwrite and shargs.append('--confirm-overwrite')
	filter and shargs.append('--file-filter=%s'%filter)
	p=Popen(shargs,stdout=PIPE)
	try :
		p= p.communicate()[0].strip()
		if multiple:
			p=tuple(p.split('|'))
		return p
	except:
		return ''

def browse(*args,**kargs):
	fn=tkbrowse
	if sys.platform=='linux2':
		try:
			Popen(['zenity','--help'],stdout=PIPE)
			fn=gbrowse
		except OSError:
			fn=tkbrowse
	return fn(*args,**kargs)

def tkbrowse(filename=None,title=None,multiple=False,
			dironly=False,savemode=False,
			confirm_overwrite=True,filter=None):
	if not dironly:
		filter=[('',i) for i in filter.split(' ')] if filter else [('All files','*')]
		if savemode:
			fn=FD.asksaveasfilename
		else:
			fn=FD.askopenfilename
		return fn(filetypes=filter,title=title,multiple=multiple)
	else:
		return FD.askdirectory(title=title,initialdir=os.path.dirname(filename) if filename else None)


class FileEntry(Frame):
	def __init__(self,root,variable,text='Browse',
				dironly=False,confirm_overwrite=True,
				savemode=False,filter=None,*args,**kargs):
		Frame.__init__(self,root,*args,**kargs)
		self._var=variable
		self._entry=Entry(self,textvariable=variable)
		self._entry.pack(padx=0,pady=0,fill=BOTH,expand=1,side=LEFT)
		self._button=Button(self,text=text,padx=5,pady=1,command=self.openbrowser)
		self._button.pack(padx=0,pady=0,expand=1,side=LEFT,anchor=W)
		self._dironly=dironly
		self._confirm_overwrite=confirm_overwrite
		self._savemode=savemode
		self._filter=filter

	def openbrowser(self):
		ret=browse(filename=self._var.get(),dironly=self._dironly,savemode=self._savemode,filter=self._filter)
		if ret:self._var.set(ret)




if __name__ == '__main__':
	main()
