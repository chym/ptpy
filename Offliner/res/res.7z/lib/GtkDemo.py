#!/usr/bin/env python
# -*- coding: utf-8 -*-
import gtk



def main():
	w=gtk.Window()
	#print gtk.FileChooserDialog(title="请选择文件",action="save").show()
	b=gtk.FileChooserButton(title="Title!!!")
	w.add(b)
	b.show()
	w.show()
	gtk.main()


if __name__ == '__main__':
  main()
