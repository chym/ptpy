#!/usr/bin/env python
# -*- coding: utf-8 -*-
#:ConfEditor.py
from ExtPython import *
from ConfUtils import *
from Tkinter import *
import Pmw,GUIKit as GK,urllib
from GUIConf import *
__all__=['ConfEditor']



def main():
	conf=get_default_conf()
	root=Tk()
	#Pmw.initialise()
	editor=ConfEditor(root,conf)
	editor.show()

	return 0


lang=get_lang()


class ConfEditor(Object):
	def __init__(self,w,conf,title=None):
		self.conf=conf
		root=self.root=Toplevel(w)
		self.root.transient(w)
		self.title=title or (unicode(lang['DIALOG']['PROPERTY'],'utf-8')+' - '+conf['name'])
		root.title(self.title)
		self.root.resizable(width=False,height=False)
		self.notebook=Pmw.NoteBook(root)
		self.vars={}




		lc=lang['DIALOG']
		pages=(lc['BASIC_CONFIG'],lc['FILE_TYPE_FILTER'],
		lc['PATH_FILTER'],lc['PERFORMANCE_CONFIG'],lc['OTHER_OPTION'])

		self.pages=[]

		for i in pages:
			self.pages.append(self.notebook.add(i))
		self.notebook.pack(padx=5,pady=5,fill=BOTH,expand=1)

		#self.notebook.tab(4).invoke()


		self.create_basic_conf_page(self.pages[0])
		self.create_file_filter_conf_page(self.pages[1])
		self.create_path_filter_conf_page(self.pages[2])
		self.create_perform_conf_page(self.pages[3])
		self.create_other_conf_page(self.pages[4])
		self.notebook.setnaturalsize()
		self.create_buttons()




	def show(self):

		#self.root.tk_bisque()
		#self.root.overrideredirect(1)
		w=self.root
		w.protocol('WM_DELETE_WINDOW',self.close)
		w.update_idletasks()
		w.wait_visibility()
		w.deiconify()
		w.grab_set()
		w.mainloop()
		w.destroy()




	def close(self):
		self.root.quit()
		self.root.destroy()
		return self

	def onconfirm(self):
		#print self.get_new_conf()
		return self

	def onapply(self):
		self.onconfirm()
		return self

	def confirm(self):
		if self.onconfirm():
			self.close()

	def apply(self):
		self.onapply()
		return self

	def get_new_conf(self):
		conf=self.conf
		keys=['auto-backup','compress-js','name','compress-css',
		'path-depth','url','file-count-max','deny-ftp','file-size-max',
		'retry','disk-useage-max','timeout','auto-prompt-oncomplete',
		'path','compress-html','max-thread']
		for k in keys:
			conf[k]=self.vars[k].get()

		conf['filetype-filter']['deny-noextname']=self.vars['deny-noextname'].get()
		conf['filetype-filter']['deny-unknown-mime']=self.vars['deny-unknown-mime'].get()

		aaft=self.vars['allow-assigned-file-type'].get()
		daf=self.vars['download-all-files'].get()

		extname_list=self.extname_listbox.get()
		if '*' in extname_list or not extname_list:
			daf=True

		if daf:
			conf['filetype-filter']['allow-extname']='*'
			conf['filetype-filter']['allow-mime']='*/*'
		elif aaft:
			conf['filetype-filter']['allow-extname']=','.join(extname_list)
		else:
			conf['filetype-filter']['deny-extname']=','.join(extname_list)

		path_list=self.path_listbox.get()
		if path_list:
			conf['path-filter']['deny']=','.join(path_list)

		conf['disk-useage-max']*=1024*1024
		conf['file-size-max']*=1024

		return conf

	def create_var(self,klass,name,value=None):
		v=klass()
		if name and value==None:value=self.conf[name]
		v.set(value)
		if name:self.vars[name]=v
		return v

	def create_buttons(self):
		root=self.root
		l=lang['BUTTON']
		btnb=Pmw.ButtonBox(root)
		btnb.pack(padx=10,pady=10)
		btnb.add(l['OK'],command=self.confirm)
		btnb.add(l['APPLY'],command=self.apply)
		btnb.add(l['CANCEL'],command=self.close)


	def create_basic_conf_page(self,frame):
		lc=lang['DIALOG']
		conf=self.conf

		g=Pmw.Group(frame,tag_text=lc['PROJECT_PLACE'])
		gframe=g.interior()
		wrap=Frame(gframe)
		wrap.pack(side=TOP,fill=X,expand=1)
		Label(wrap,text=lc['PROJECT_NAME']+":").pack(padx=5,pady=5,side=LEFT)
		var=self.create_var(StringVar,'name')
		entry=self.project_name_entry=Entry(wrap,textvariable=var)
		entry.pack(padx=5,pady=5,side=LEFT,fill=X,expand=1)
		wrap=Frame(gframe)
		wrap.pack(side=TOP,fill=X,expand=1)
		Label(wrap,text=lc['PROJECT_PLACE']+":").pack(padx=5,pady=5,side=LEFT)
		var=self.create_var(StringVar,'path')
		self.project_path_entry=GK.FileEntry(wrap,text=lc["BROWSE"],variable=var,dironly=True)
		self.project_path_entry.pack(side=LEFT,expand=1,fill=BOTH,padx=5,pady=5)

		g.pack(padx=5,pady=5,fill=X,side=TOP,expand=0)



		g=Pmw.Group(frame,tag_text=lc['ADDRESS_CONFIG_LABEL'])
		gframe=g.interior()
		wrap=Frame(gframe)
		wrap.pack(side=TOP,fill=X,expand=1)
		Label(wrap,text=lc['ADDRESS_START']+":").pack(padx=5,pady=5,side=LEFT)
		var=self.create_var(StringVar,'url')
		self.url_entry=Entry(wrap,textvariable=var)
		self.url_entry.pack(padx=5,pady=5,side=LEFT,fill=X,expand=1)


		wrap=Frame(gframe)
		wrap.pack(side=TOP,fill=X,expand=1)
		var=self.create_var(IntVar,'path-depth',(conf['path-depth'] or 10))
		counter=Pmw.Counter(wrap,entry_textvariable=var,labelpos=W,label_text=lc['PATH_DEPTH_LIMIT']+":",
		entryfield_validate={'validator':'integer','min':1,'max':100},
		labelmargin=4,entry_width=8)
		counter.pack(expand=0,side=LEFT,padx=5,pady=5)

		g.pack(padx=5,pady=5,fill=X,side=TOP,expand=1)

		g=Pmw.Group(frame,tag_pyclass=None)
		gframe=g.interior()
		var=self.create_var(BooleanVar,'auto-backup')
		Checkbutton(gframe,text=lang['TEXT']['AUTO_BAKUP'],
		variable=var,anchor=W).pack(padx=5,pady=5,side=TOP,anchor=W)

		var=self.create_var(BooleanVar,'auto-prompt-oncomplete')
		Checkbutton(gframe,text=lang['TEXT']['AUTO_PROMPT_ONCOMPLETE'],
		variable=var,anchor=W).pack(padx=5,pady=5,side=TOP,anchor=W)

		var=self.create_var(BooleanVar,'deny-ftp')
		Checkbutton(gframe,text=lang['TEXT']['DENY_FTP'],
		variable=var,anchor=W).pack(padx=5,pady=5,side=TOP,anchor=W)

		g.pack(padx=5,pady=5,fill=BOTH,side=TOP,expand=1)

	def create_file_filter_conf_page(self,frame):
		lc=lang['DIALOG']
		lt=lang['TEXT']
		conf=self.conf

		wrap=Frame(frame)
		var=self.create_var(BooleanVar,'download-all-files',conf['filetype-filter']['allow-extname']=='*')
		rbtn=Radiobutton(wrap,variable=var,text=lt['DOWNLOAD_ALL_FILES'],value=True)
		rbtn.pack(side=TOP,anchor=W)


		rbtn=Radiobutton(wrap,variable=var,text=lt['DOWNLOAD_ASSIGNED_FILES'],value=False)
		rbtn.pack(side=TOP,anchor=W)

		wrap.pack(fill=X,expand=0,padx=5,pady=5,side=TOP)


		g=Pmw.Group(frame,tag_text=lt['EDIT_FILE_TYPE_LIST'])
		gframe=g.interior()

		above=Frame(gframe)

		above_left=Frame(above)

		extname_listbox=Pmw.ScrolledListBox(above_left,#listbox_selectmode=SINGLE,
				items=self.get_filetype_filter(),listbox_height=5,
				vscrollmode='static',hscrollmode='none',usehullsize=1,hull_width=180,hull_height=200)
		extname_listbox.pack(fill=BOTH,expand=1,padx=5,pady=5)
		self.extname_listbox=extname_listbox

		above_left.pack(side=LEFT,expand=0,padx=5,pady=5)


		above_right=Frame(above)
		extname_entry=Entry(above_right)
		extname_entry.pack(padx=5,pady=5,side=TOP,fill=X,expand=1,anchor=NW)
		self.extname_entry=extname_entry

		btn=Button(above_right,text=lt['ADD_EXTNAME'],command=self.add_extname_to_listbox)

		btn.pack(side=TOP,padx=5,pady=5,expand=1,anchor=NW,fill=X)

		btn=Button(above_right,text=lt['DEL_SELECTED_EXTNAME'],command=self.del_extname_from_listbox)

		btn.pack(side=TOP,padx=5,pady=5,expand=1,anchor=NW,fill=X)

		var=self.create_var(BooleanVar,'deny-unknown-mime',self.conf['filetype-filter']['deny-unknown-mime'])
		cbtn=Checkbutton(above_right,text=lt['DENY_UNKNOWN_MIME'],variable=var)
		cbtn.pack(side=TOP,padx=5,pady=5,expand=1,anchor=NW)

		var=self.create_var(BooleanVar,'deny-noextname',self.conf['filetype-filter']['deny-noextname'])
		cbtn=Checkbutton(above_right,text=lt['DENY_NOEXTNAME_FILE'],variable=var)
		cbtn.pack(side=TOP,padx=5,pady=5,expand=1,anchor=NW)

		above_right.pack(side=LEFT,expand=0,padx=5,pady=5,anchor=N)

		above.pack(side=TOP,padx=5,pady=5,expand=0,fill=X)


		below=Frame(gframe)
		var=self.create_var(BooleanVar,'allow-assigned-file-type',not conf['filetype-filter']['deny-mime'])
		rbtn=Radiobutton(below,text=lt['ALLOW_ASSIGNED_FILE_TYPE'],value=True,variable=var)
		rbtn.pack(anchor=W,side=LEFT)
		rbtn=Radiobutton(below,text=lt['DENY_ASSIGNED_FILE_TYPE'],value=False,variable=var)
		rbtn.pack(anchor=W,side=LEFT)

		below.pack(side=TOP,padx=5,pady=5,expand=0,fill=X)
		g.pack(expand=0,padx=5,pady=5,side=TOP,fill=X)

	def create_path_filter_conf_page(self,frame):
		lt=lang['TEXT']
		conf=self.conf
		g=Pmw.Group(frame,tag_text=lt['EDIT_PATH_FILTER_LIST'])
		gframe=g.interior()

		path_listbox=Pmw.ScrolledListBox(gframe,listbox_selectmode=SINGLE,
				items=self.get_path_filter(),listbox_height=5,
				vscrollmode='static',hscrollmode='none',usehullsize=1,hull_width=180,hull_height=200)
		path_listbox.pack(fill=BOTH,expand=1,padx=5,pady=5)
		self.path_listbox=path_listbox

		path_listbox.pack(side=LEFT,expand=0,padx=5,pady=5)


		frame_right=Frame(gframe)
		path_entry=Entry(frame_right)
		path_entry.pack(padx=5,pady=5,side=TOP,fill=X,expand=1,anchor=NW)
		self.path_entry=path_entry

		btn=Button(frame_right,text=lt['ADD_PATH'],command=self.add_path_to_listbox)

		btn.pack(side=TOP,padx=5,pady=5,expand=1,anchor=NW,fill=X)

		btn=Button(frame_right,text=lt['DEL_SELECTED_PATH'],command=self.del_path_from_listbox)

		btn.pack(side=TOP,padx=5,pady=5,expand=1,anchor=NW,fill=X)


		frame_right.pack(side=LEFT,expand=0,padx=5,pady=5,anchor=N)

		g.pack(fill=X,expand=0,side=TOP,padx=5,pady=5)
		return


	def create_perform_conf_page(self,frame):
		lt=lang['TEXT']
		conf=self.conf
		g=Pmw.Group(frame,tag_text=lt['PERFORMANCE'])
		gframe=g.interior()


		var=self.create_var(IntVar,'max-thread',(conf['max-thread'] or 10))
		counter=Pmw.Counter(gframe,entry_textvariable=var,labelpos=W,label_text=lt['MAX_THREAD']+":",
		entryfield_validate={'validator':'integer','min':1,'max':100},
		labelmargin=4,entry_width=8,label_width=30,label_anchor=E)
		counter.pack(expand=0,side=TOP,padx=10,pady=5,anchor=W)

		var=self.create_var(IntVar,'timeout',(conf['timeout'] or 10))
		counter=Pmw.Counter(gframe,entry_textvariable=var,labelpos=W,label_text=lt['TIMEOUT_WAIT']+":",
		entryfield_validate={'validator':'integer','min':1,'max':100},
		labelmargin=4,entry_width=8,label_width=30,label_anchor=E)
		counter.pack(expand=0,side=TOP,padx=10,pady=5,anchor=W)

		var=self.create_var(IntVar,'retry')
		counter=Pmw.Counter(gframe,entry_textvariable=var,labelpos=W,label_text=lt['RETRY_TIMES']+":",
		entryfield_validate={'validator':'integer','min':1,'max':10},
		labelmargin=4,entry_width=8,label_width=30,label_anchor=E)
		counter.pack(expand=0,side=TOP,padx=10,pady=5,anchor=W)

		g.pack(fill=X,expand=0,side=TOP,padx=5,pady=5)

		
		g=Pmw.Group(frame,tag_text=lt['FILE_SIZE_LIMIT'])
		gframe=g.interior()


		var=self.create_var(IntVar,'disk-useage-max')
		counter=Pmw.Counter(gframe,entry_textvariable=var,labelpos=W,label_text=lt['DISK_USAGE_MAX']+":",
		entryfield_validate={'validator':'integer','min':0,'max':9999},
		labelmargin=4,entry_width=8,label_width=30,label_anchor=E)
		counter.pack(expand=0,side=TOP,padx=10,pady=5,anchor=W)

		var=self.create_var(IntVar,'file-count-max')
		counter=Pmw.Counter(gframe,entry_textvariable=var,labelpos=W,label_text=lt['FILE_COUNT_MAX']+":",
		entryfield_validate={'validator':'integer','min':0,'max':99999},
		labelmargin=4,entry_width=8,label_width=30,label_anchor=E)
		counter.pack(expand=0,side=TOP,padx=10,pady=5,anchor=W)

		var=self.create_var(IntVar,'file-size-max')
		counter=Pmw.Counter(gframe,entry_textvariable=var,labelpos=W,label_text=lt['FILE_SIZE_MAX']+":",
		entryfield_validate={'validator':'integer','min':0,'max':9999},
		labelmargin=4,entry_width=8,label_width=30,label_anchor=E)
		counter.pack(expand=0,side=TOP,padx=10,pady=5,anchor=W)

		g.pack(fill=X,expand=0,side=TOP,padx=5,pady=5)




		return

	def create_other_conf_page(self,frame):
		lt=lang['TEXT']
		conf=self.conf
		g=Pmw.Group(frame,tag_text=lt['COMPRESS_OPTION'])
		gframe=g.interior()

		var=self.create_var(BooleanVar,'compress-html')
		cbtn=Checkbutton(gframe,text=lt['COMPRESS_HTML'],variable=var)
		cbtn.pack(side=LEFT,padx=5,pady=5,anchor=W)

		var=self.create_var(BooleanVar,'compress-css')
		cbtn=Checkbutton(gframe,text=lt['COMPRESS_CSS'],variable=var)
		cbtn.pack(side=LEFT,padx=5,pady=5,anchor=W)

		var=self.create_var(BooleanVar,'compress-js')
		cbtn=Checkbutton(gframe,text=lt['COMPRESS_JS'],variable=var)
		cbtn.pack(side=LEFT,padx=5,pady=5,anchor=W)

		g.pack(fill=X,expand=0,side=TOP,padx=5,pady=5)

		g=Pmw.Group(frame,tag_text=lt['COMMENT'])
		gframe=g.interior()

		self.comment_st=Pmw.ScrolledText(gframe,borderframe=1,usehullsize=1,hscrollmode='none',
		hull_height=300,text_padx=10,text_pady=10,text_wrap='word')
		self.comment_st.settext(conf['comment'])
		self.comment_st.pack(fill=X,padx=5,pady=5)

		g.pack(fill=X,expand=0,side=TOP,padx=5,pady=5)
		return



	def get_path_filter(self):
		pathes=self.conf['path-filter']['deny']
		return [] if not pathes else pathes.split(',')
	def get_filetype_filter(self):
		conf=self.conf['filetype-filter']
		if conf['deny-extname']:
			return conf['deny-extname'].split(',')
		else:
			return conf['allow-extname'].split(',')

	def add_extname_to_listbox(self):
		l=self.extname_listbox
		items=l.get()
		entry=self.extname_entry
		s=entry.get().lower()

		if s not in items and isalnum(s):l.insert(END,s)
		entry.delete(0,len(s))
		return

	def add_path_to_listbox(self):
		l=self.path_listbox
		items=l.get()
		entry=self.path_entry
		s=entry.get().lower()

		if s not in items:l.insert(END,urllib.quote(s))
		entry.delete(0,len(s))
		return

	def del_extname_from_listbox(self):
		l=self.extname_listbox
		i=l.curselection()
		if i and i[0]:
			l.delete(i[0])
		return

	def del_path_from_listbox(self):
		l=self.path_listbox
		i=l.curselection()
		if i and i[0]:
			l.delete(i[0])
		return





if __name__ == '__main__':
	main()

