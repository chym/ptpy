#!/usr/bin/env python
# -*- coding: utf-8 -*-
#:FileUtils.py
import os,mimetypes,urllib,datetime,gzip
from ExtPython import *
from urllib import urlretrieve
from time import sleep

#from FileUtils import *
__all__=['sameurl','parseurl','extname','mime_type','mime_ext','mime_type_unix','LocalFile','RemoteFile',
		'joinurl','realurl','samedomain','relative_path']

def main():
	print 'FileUtils Test!!!'
	f=RemoteFile("ftp://cj:cj@localhost/bin/color")
	print f.getsize("KB"),"KB"
	print f.getextname()
	print f.getctime()
	print f.getmtime()
	print f.getdir()
	url1="http://www.PL4CJ.org:80/blog/index.php"
	url2="HTTP://www.pl4cj.org/blog/index.php?param=1"
	print sameurl(url1,url2,True)
	return 0

_sameurl_cache_={}
def sameurl(url1,url2,I=False):# I ignore_query
	url1=url1.lower()
	url2=url2.lower()
	if url1==url2:
		return True
	t=(url1,url2,I)
	if not _sameurl_cache_.has_key((url1,url2)):
		t1=parseurl(url1,I)
		t2=parseurl(url2,I)
		_sameurl_cache_[t]= t1==t2
	return _sameurl_cache_[t]

_parseurl_cache_={}
def parseurl(url,I=False):
	t=(url,I)
	if not _parseurl_cache_.has_key(url):
		from urlparse import urlparse,parse_qs
		t=urlparse(url,allow_fragments=True)
		data={
			"domain":t.netloc.lower(),
			"scheme":t.scheme,
			"path":os.path.dirname(t.path),
			"filename":os.path.basename(t.path),
			"query":'' if I or not t.query else parse_qs(t.query)
		}
		if data['domain'].startswith('www.'):
			data['domain']=data['domain'][3:]
		if data['domain'].endswith(':80'):
			data['domain']=data['domain'][0:-3]
		if data['path'] and data['path'] != '/':
			if data['scheme']:
				data['path']=data['path'].lstrip('/')
				data['path']='/'+data['path']
				data['path']=os.path.realpath(data['path'])
				if ':' in data['path']:
					data['path']=data['path'][2:].replace('\\','/')
			if data['path'][-1] !='/':
				data['path']+='/'

		#if data['scheme']=='http' and data['domain']:
		#	data['wdomain']='www.'+data['domain']
		_parseurl_cache_[t]=data
	return _parseurl_cache_[t]



def joinurl(url_dict,domain=None,scheme=None,w=False):
	"""
	joinurl(url_dict,domain=None,scheme=None)
	url_dict is the return value of parseurl
	"""
	if domain:
		if not scheme:scheme='http'
		if domain.startswith('www.'):
			domain=domain[3:]
		if domain.endswith(':80'):
			domain=domain[0:-3]
		url_dict["domain"]=domain
		url_dict["scheme"]=scheme

	ret=url_dict["scheme"]
	if ret:
		ret+="://"
	if url_dict["scheme"]=='http' and w:
		ret+='www.'
	ret+=url_dict["domain"]+url_dict["path"]+url_dict["filename"]
	if url_dict["query"]:
		ret +='?'+urllib.urlencode(url_dict["query"],True)
	return ret

def realurl(url,domain=None,scheme=None,w=False):
	return joinurl(parseurl(url),domain,scheme,w)

def samedomain(domain,link):
	if '://' not in link:
		return True
	link=parseurl(link)
	return	not link['domain'] or domain==link['domain']



def extname(basename):
	dotpos=basename.rfind(".")
	return basename[dotpos+1:] if dotpos >0 else ""

def relative_path(path,base_path):
	if path[0]!='/':
		return path
	rurl="..".join(['/']*(len(base_path.split('/'))-1))+path.lstrip('/')
	return rurl.lstrip('/')


def mime_type_unix(filename):
	"""
	mime_type_unix(filename)
	use unix toolkit "file" to detect file mime type
	"""
	from subprocess import Popen,PIPE
	p1=Popen(['file','--mime-type',filename],stdout=PIPE)
	p2=Popen(['awk','{print $2}'],stdin=p1.stdout,stdout=PIPE)
	try:
		return p2.communicate()[0].strip()
	except:
		return ""

def mime_type(extname):
	"""
	mime_type(extname)
	also you can use mimetypes.guess_type(filename)
	"""
	from mime_list import all
	return all.get(extname,all[""])

def mime_ext(mime):
	"""
	mime_ext(mime)
	also you can use mimetypes.guess_extension(mime),but it has a problem,example:mimetypes.guess_extension('text/plain') will return .ksh!!!
	"""
	if mime=='text/plain':
		return 'txt'
	from mime_list import all
	for k in all:
		if all[k]==mime:
			return k
	return ''

class File(Object):
	BSIZE={"B":1.0,"KB":1024.0,"MB":1048576.0}
	def __init__(self):
		raise NotImplementedError("Abstract Class [File]")
	def __getattr__(self,name):
		return getattr(self._file,name)

	def __hash__(self):
		return hash(self._file)
	def __id__(self):
		return id(self._file)

	def __iter__(self):
		return self._file

	def __str__(self):
		return "%s:%s"%(object.__repr__(self),self._file)

	__repr__=__str__


	def getmime(self):
		return self._mime

	def getsize(self,unit='B'):
		return float("%.2f"%(self._size/self.BSIZE.get(unit,self.BSIZE['B'])))

	def getname(self):
		return self._basename

	def getdir(self):
		return self._dir

	def getextname(self):
		return self._extname

	def getctime(self):
		return self._ctime

	def getmtime(self):
		return self._mtime



class LocalFile(File):
	"""
	LocalFile:a wrap class for file,also extends some userful method.
	"""

	def __init__(self,filename,mode='r',bufsize=-1):
		self._file=open(filename,mode,bufsize)
		self._filename=filename
		self._dir=os.path.dirname(filename)+"/"
		self._basename=os.path.basename(filename)
		self._extname=extname(self._basename)
		self._size=os.path.getsize(filename)
		self._mime=mimetypes.guess_type(filename) or mime_type_unix(filename)
		self._mtime=datetime.datetime.fromtimestamp(os.path.getmtime(filename))
		self._ctime=datetime.datetime.fromtimestamp(os.path.getctime(filename))

	def __eq__(self,another):
		return os.path.samefile(self._filename,another._filename)




class RemoteFile(File):
	"""
	RemoteFile:a class to process httpfile or ftpfile
	"""
	def __init__(self,url,*args,**kargs):
		self._file=urllib.urlopen(url,*args,**kargs)
		self._url=url
		t=parseurl(url)
		self.path=t["path"]
		self.domain=t["domain"]
		self.scheme=t["scheme"]
		#property:headers is self.__file.headers ,instanceof HTTPMessage
		self._size=intval(self.headers.getheader('Content-Length'))
		self._mime=self.headers.type
		self._basename=t['filename']

		self.oextname=extname(self._basename) #original extension name

		if self._mime in mimetypes.guess_type("A."+self.oextname):
			self._extname=self.oextname
		else:
			#self._extname=mimetypes.guess_extension(self._mime)
			#self._extname=self._extname[1:] if self._extname else self.oextname #remove dot
			self._extname=mime_ext(self._mime)
		date_tuple=self.headers.getdate('date')
		self._mtime=self._ctime=datetime.datetime(*(date_tuple[0:6]+(date_tuple[-1],))) if date_tuple else datetime.datetime.now()

	def __eq__(self,another):
		return sameurl(self._url,another._url,True) and self._size==another._size



	def retrieve(self,path,unzip=True):
		if self.headers.getheader('Content-Encoding')=='gzip' and unzip:
			f=open(path,'w')
			f.write(self.read())
			f.close()
			f=gzip.open(path,'rb')
			content=f.read()
			f.close()
			f=open(path,'w')
			f.write(content)
			f.close()
			self._size=len(content)
		else:
			def assign_size(block_count,block_size,total_size):
				self._size=total_size
			urlretrieve(self._url,path,assign_size)
			sleep(1)


def clear_cache():
	global _sameurl_cache_,_parseurl_cache_
	_sameurl_cache_={}
	_parseurl_cache_={}
	return 0

#setInterval(clear_cache,10)

if __name__ == '__main__':
	main()
