#!/usr/bin/env python
# -*- coding: utf-8 -*-
#:PathConf.py
__all__=['path_conf']
path_conf={
	'conf_xml':'conf.xml',
	'conf_dump':'conf.dump',
	'url_all':'url-all',
	'url_complete':'url-complete',
	'url_nocomplete':'url-nocomplete',
	'archive_dir':'archive/',
	'archive_bak_dir':'archive-bak-dir/',
	'tmp_dir':'tmp/',
	'default_conf_xml':'''/conf/default-conf.xml''',
	'default_conf_dump':'''/conf/default-conf.dump''',
	'gui_conf':'''/conf/gui-conf.dump''',
	'lang_path':'''/conf/lang/''',
	'welcome_file':'''/conf/welcome.txt'''
}

import os
cur=os.path.realpath('.')
s=['default_conf_xml','default_conf_dump','gui_conf','lang_path','welcome_file']
for i in s:
	path_conf[i]=cur+path_conf[i]
	print path_conf[i]