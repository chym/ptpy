#!/usr/bin/env python
# -*- coding: utf-8 -*-
#:offliner.py

"""
兼容Python 2.6
必须要有Tkinter和Pmw库
"""

from lib.RootWindow import *
def main():
	
	#import lib.PathConf
	RootWindow()

if __name__ == '__main__':
	main()
